# EGR314 201A3 main program
# Upstream refers to the controller (A1/A2 network), downstream refers to the boat (other subsystems)
# TODO: Add heartbeat system

from micropython import const
from machine import UART
import asyncio
import aioble
import bluetooth
import struct
import time

# Pinout
uart = UART(2, 9600,tx=17,rx=16)
uart.init(9600, bits=8, parity=None, stop=1,flow=0)

# Vars
team_ids=['A','B','C','D','E','F','G','H','I','J','X']
_BLE_SERVICE_UUID = bluetooth.UUID('8bbd8ff7-3d84-4e81-9d46-70b6cb79e76a')
_BLE_UPSTREAM_UUID = bluetooth.UUID('5699aead-41fc-4705-9c65-7c84d8bcb04c')
_BLE_DOWNSTREAM_UUID = bluetooth.UUID('a037a1df-ccaf-480c-b7a4-6526a6848887')
_BLE_HEARTBEAT_UUID = bluetooth.UUID('24ef4bcf-9f6e-4dec-894f-090aadfbf75d')
_BLE_ROLLCALL_UUID = bluetooth.UUID('d9cba376-e9c9-4db7-a6f2-4c6783c1dade')
_ADV_INTERVAL_MS = 250_000

# BLE
ble_service = aioble.Service(_BLE_SERVICE_UUID)
upstream_characteristic = aioble.Characteristic(ble_service, _BLE_UPSTREAM_UUID, read=True, notify=True)
# capture property allows other ble devices to write to this charecteristic
downstream_characteristic = aioble.Characteristic(ble_service, _BLE_DOWNSTREAM_UUID, read=True, write=True, notify=True, capture=True)
aioble.register_services(ble_service)

downstream_msg = bytearray(4)

#OPTIMIZE: This is egregiously inefficient.
async def uart_recieve():
	while True:
		try:
			raw_msg = uart.read()
			if not raw_msg:
		                continue
#OPTIMIZE: make this filtering a function so it can be implemented elsewhere if needed.
			if len(raw_msg) >= 6:
				print('[INFO] UART_RX: valid message size')
				if raw_msg[0] == ord('A') and raw_msg[1] == ord('Z'):
        		                print('[INFO] UART_RX: valid start bytes recieved')
					if raw_msg[ len(raw_msg) - 2 ] == ord('Y') and raw_msg[ len(raw_msg) - 1 ] == ord('B'):
						print('[INFO] UART_RX: valid stop bytes recieved')
						if chr(raw_msg[2]) in team_ids:
							print('[INFO] UART_RX: valid sender ID')
							if raw_msg[2] == ord('C'):
								print('[INFO] UART_RX: recieved message sent by self. Ignoring.')
							elif chr(raw_msg[3]) in team_ids:
        	                                                print('[INFO] UART_RX: valid reciever ID')
# upstream bluetooth communication
								if raw_msg[3] == ord('A') or raw_msg[3] == ord('B'):
									upstream_characteristic.write(raw_msg, send_update=True)
							                print('[INFO] BLE_upstream: sent upstream message: ', raw_msg)
								elif raw_msg[3] == ord('C'):
                                                                        print('[WARNING] UART_RX: recieved uart message addressed to self, no API available. Ignoring.')
# rollcall
								elif raw_msg[3] == ord('X'):
									print('[DEBUG] UART_RX: recieved rollcall, PRESENT!')
									upstream_characteristic.write(raw_msg, send_update=True)
                                                                        print('[INFO] BLE_upstream: sent rollcall message: ', raw_msg)
									swriter = asyncio.StreamWriter(uart, {})
                                                                        swriter.write(raw_msg)
                                                                        print("[INFO] UART_RX: passed rollcall message: ",raw_msg)
# pass messages not addressed to remote downstream
								else:
									swriter = asyncio.StreamWriter(uart, {})
					                        	swriter.write(raw_msg)
									print("[INFO] UART_RX: passed message ",raw_msg)
                	                                else:
                        	                                print('[ERROR] UART_RX: invalid reciever ID')
						else:
							print('[ERROR] UART_RX: invalid sender ID')
					else:
						print('[ERROR] UART_RX: failed to identify stop bytes')
                		else:
                        		print('[ERROR] UART_RX: failed to identify start bytes')
			else:
				print('[ERROR] UART_RX: message size invalid')

		except asyncio.CancelledError:
			print("[ERROR] asyncio: uart recieve task cancelled")
		except Exception as e:
			print("[ERROR] asyncio: error in uart recieve task:", e)
		finally:
			await asyncio.sleep_ms(100)

# Host peripheral service
# Advertising stopped when central connected
async def peripheral_task():
    while True:
        try:
            async with await aioble.advertise(
                _ADV_INTERVAL_MS,
                name="duck_201A3",
                services=[_BLE_SERVICE_UUID],
                ) as connection:
                    print("[INFO] BLE_peripheral: connection from", connection.device)
                    await connection.disconnected()
        except asyncio.CancelledError:
            # Catch the CancelledError
            print("[ERROR] asyncio: ble peripheral task cancelled")
        except Exception as e:
            print("[ERROR] asyncio: error in peripheral task:", e)
        finally:
            await asyncio.sleep_ms(100)

async def downstream_read():
	while True:
		try:
			connection, data = await downstream_characteristic.written()
			print('[INFO] BLE_downstream: connection: ', connection)
			# filter message here
			downstream_msg = data
			print('[INFO] BLE_downstream: recieved message: ',downstream_msg)
			swriter = asyncio.StreamWriter(uart, {})
			swriter.write(downstream_msg)
			print('[INFO] UART_TX: sent message: 'downstream_msg)
			await swriter.drain()
		except asyncio.CancelledError:
			print("[ERROR] asyncio: ble downstream task cancelled")
		except Exception as e:
			print("[ERROR] asyncio: error in ble downstream task:", e)
		finally:
			await asyncio.sleep_ms(100)

# Main
async def main():
	print('[INFO] asyncio: subsystem 201A3 program started. /nFor production, do not take further action. 201A2 will connect automatically if in range. /nFor debugging, connect to MAC address D4:8C:49:E4:D3:8A.')
#OPTIMIZE: gather appears to be bad practice in python3, change this to a task group if time permits
	t1 = asyncio.create_task(uart_recieve())
	t2 = asyncio.create_task(peripheral_task())
	t3 = asyncio.create_task(downstream_read())
	await asyncio.gather(t1,t2)

asyncio.run(main())
